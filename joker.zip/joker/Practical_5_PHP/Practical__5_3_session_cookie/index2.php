<?php
// Start the session
session_start();

// If a POST request with a username was made, set a cookie
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['username'])) {
    $name = htmlspecialchars($_POST['username']);
    setcookie('username', $name, time() + (86400 * 30), "/"); // Cookie valid for 30 days
    $_COOKIE['username'] = $name; // So it’s immediately available
}

// Track visits in this session
if (isset($_SESSION['visit_count'])) {
    $_SESSION['visit_count'] += 1;
} else {
    $_SESSION['visit_count'] = 1;
}

// Get username from cookie if available
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Session and Cookie Demo</title>
</head>
<body>
<h1>Welcome to Session and Cookie Demo</h1>

<?php if ($username): ?>
    <p>Hello, <strong><?php echo htmlspecialchars($username); ?></strong>! Welcome back.</p>
<?php else: ?>
    <p>Hello, guest! Please enter your name:</p>
    <form method="POST" action="">
        <input type="text" name="username" placeholder="Your name" required />
        <button type="submit">Submit</button>
    </form>
<?php endif; ?>

<p>You have visited this page <strong><?php echo $_SESSION['visit_count']; ?></strong> time(s)
during this session.</p>

<p><a href="logout.php">Clear Session and Cookie</a></p>
</body>
</html>
