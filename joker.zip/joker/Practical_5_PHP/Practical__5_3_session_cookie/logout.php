<?php
session_start();

// Clear session data
session_unset();
session_destroy();

// Clear cookie by expiring it
setcookie('username', '', time() - 3600, "/");

// Redirect back to main page
header("Location: index2.php");
exit;
?>
