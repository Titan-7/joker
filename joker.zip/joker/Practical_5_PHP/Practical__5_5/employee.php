<?php
// Database config
$servername = "localhost";
$username = "root";
$password = ""; // change if needed
$dbname = "company_db";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);

// Handle form submission
$message = ""; if
($_SERVER['REQUEST_METHOD'] === 'POST') {
// Simple validation (you can expand this)
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$position = trim($_POST['position']);
if ($name && $email && $position) {
// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("INSERT INTO employees (name, email, position) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $position);

if ($stmt->execute()) {
$message = "Employee record added successfully!";
} else {
$message = "Error: " . $stmt->error;
}
$stmt->close();
} else {
$message = "Please fill all fields.";
}
}
// Fetch all employees
$result = $conn->query("SELECT * FROM employees ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Employee Records</title>
</head>
<body>
<h1>Employee Records</h1>
<?php if ($message): ?>
<p><strong><?php echo htmlspecialchars($message); ?></strong></p>
<?php endif; ?>
<h2>Add New Employee</h2>
<form method="POST" action="">
<label>
Name:<br>
<input type="text" name="name" required>
</label><br><br>
<label>
Email:<br>
<input type="email" name="email" required>
</label><br><br>
<label>
Position:<br>
<input type="text" name="position" required>
</label><br><br>
<button type="submit">Add Employee</button>
</form>
<hr>
<h2>Employee List</h2>
<?php if ($result->num_rows > 0): ?>
<table border="1" cellpadding="8" cellspacing="0">
<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Position</th>
<th>Created At</th>
</tr>
</thead>
<tbody>
<?php while ($row = $result->fetch_assoc()): ?>
<tr>
<td><?php echo htmlspecialchars($row['id']); ?></td>
<td><?php echo htmlspecialchars($row['name']); ?></td>
<td><?php echo htmlspecialchars($row['email']); ?></td>
<td><?php echo htmlspecialchars($row['position']); ?></td>
<td><?php echo htmlspecialchars($row['created_at']); ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p>No employee records found.</p>
<?php endif; ?>
</body>
</html>
<?php
$conn->close();
?>
