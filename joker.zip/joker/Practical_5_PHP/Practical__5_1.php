<!-- Practical:- 5.1
Aim:- PHP based web application to understand data retrieval on server side. -->

<?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "test_db";

$mysqli = new mysqli($db_host, $db_user, $db_pass);

if ($mysqli->connect_error) {
    die("Failed to connect: " . $mysqli->connect_error);
}

$createDB = "CREATE DATABASE IF NOT EXISTS `$db_name`";
if ($mysqli->query($createDB)) {
    echo "Database '$db_name' is ready.<br>";
} else {
    echo "Database creation error: " . $mysqli->error . "<br>";
}

$mysqli->select_db($db_name);

$createTable = "CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL,
    `email` VARCHAR(50),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
if ($mysqli->query($createTable)) {
    echo "Table 'users' is ready.<br>";
} else {
    echo "Error creating table: " . $mysqli->error . "<br>";
}

$countResult = $mysqli->query("SELECT COUNT(*) AS total FROM users");
$countRow = $countResult->fetch_assoc();

if ($countRow['total'] == 0) {
    $insertData = "
        INSERT INTO users (name, email) VALUES
        ('Alice', 'alice@example.com'),
        ('Bob', 'bob@example.com'),
        ('Charlie', 'charlie@example.com')
    ";
    $mysqli->query($insertData);
    echo "Sample users added.<br>";
}
$mysqli->close();
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->query("SELECT id, name, email, created_at FROM users");
    $userList = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $ex) {
    die("PDO connection failed: " . $ex->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users Table</title>
<style>
    table { border-collapse: collapse; width: 80%; margin: 20px 0; }
    th, td { padding: 8px 12px; border: 1px solid #333; text-align: left; }
    th { background-color: #f2f2f2; }
</style>
</head>
<body>
<h1>Users List</h1>
<?php if (!empty($userList)): ?>
<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Registered At</th>
    </tr>
    <?php foreach ($userList as $u): ?>
    <tr>
        <td><?= htmlspecialchars($u['id']) ?></td>
        <td><?= htmlspecialchars($u['name']) ?></td>
        <td><?= htmlspecialchars($u['email']) ?></td>
        <td><?= htmlspecialchars($u['created_at']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php else: ?>
<p>No users available.</p>
<?php endif; ?>
</body>
</html>
